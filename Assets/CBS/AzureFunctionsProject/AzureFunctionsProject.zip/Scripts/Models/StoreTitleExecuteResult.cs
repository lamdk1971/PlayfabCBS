using PlayFab.ServerModels;

namespace CBS.Models
{
    public class StoreTitleExecuteResult
    {
        public CBSStoreTitle StoreTitle;
        public GetStoreItemsResult OriginStore;
    }
}