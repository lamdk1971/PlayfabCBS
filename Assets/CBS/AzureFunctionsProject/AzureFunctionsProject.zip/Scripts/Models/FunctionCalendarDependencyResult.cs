using CBS.Models;
using PlayFab.ServerModels;
using System.Collections.Generic;

namespace CBS
{
    public class FunctionCalendarDependencyResult
    {
        public CalendarContainer Container;
        public List<ItemInstance> Inventory;
    }
}